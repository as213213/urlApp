<?php

namespace App\Providers;

use App\Passport\Token;
use App\Passport\Client;
use App\Passport\AuthCode;
use Laravel\Passport\Passport;
use App\Passport\PersonalAccessClient;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Passport::routes();

        Gate::define('privilege_group', function ($user, $privilege_group_type) {
            if ($user->userable_type == 'admin') {
                return true;
            } else {
                $privileges = $user->userable->privileges;

                foreach ($privileges as $key => $privilege) {
                    if ($privilege->privilegeGroup->unique_key == $privilege_group_type) {
                        return true;
                    }
                }
                
                return false;
            }
        });
        
        Gate::define('privilege', function ($user, $privilege_type) {
            if ($user->userable_type == 'admin') {
                return true;
            } else {
                if ($user->userable->privileges->contains('unique_key', $privilege_type)) {
                    return true;
                }
                return false;
            }
        });
    }
    
}
