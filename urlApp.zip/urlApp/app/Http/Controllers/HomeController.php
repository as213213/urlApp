<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use Charts;
use App\Link;
//use App\Charts\UserChart;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
     public function urlList()
    {
       
        $shortLinks = Link::where('user_id',auth()->user()->id)->get();
        return view('index', compact('shortLinks'));
    }

    public function index()
    {   
        $shortLinks = Link::all();

        $url = Link::where(DB::raw("(DATE_FORMAT(created_at,'%Y'))"),date('Y'))->get();

        $chart = Charts::database($url, 'bar', 'highcharts')
                  ->title("Monthly new Urls")
                  ->elementLabel("Total Url")
                  ->dimensions(1000, 500)
                  ->responsive(false)
                  ->groupByMonth(date('Y'), true);

        return view('shortenLink', [
                     'shortLinks' => $shortLinks,
                     'chart' => $chart
         ]);
    }
    public function create()
    {
         return view('home');
    }

    public function store(Request $request)
    {
        
        $request->validate([
         'url' => 'required|url'
        ]);

        $short_link = Link::create([
              'user_id'=> $request->user_id,
              'link' => $request->url,
              'code' => str_random(6),
              'visitors'=>0
        ]);
        
        if(auth()->user()->id){
               return redirect('/urlList')->with('success', 'Shorten Link Generated Successfully!');
        }else{

             return redirect('/home')->with('success', 'Shorten Link Generated Successfully!');
        }

        
    }

    //update
    public function shortenLink($id)

    {

        $code = Link::find($id);
        $visitors = $code->visitors;

        $response = $code->update([
            'visitors' => $visitors+1
        ]);

        return redirect('/home');

    }

    public function shortenLinkUser($id)

    {

        $code = Link::find($id);
        $visitors = $code->visitors;

        $response = $code->update([
            'visitors' => $visitors+1
        ]);

        return redirect('/urlList');

    }

     public function show($id)
    {
        $url = Link::findOrFail($id);

        return view('show',  [
            'data' => $url
        ]);
    }
}
