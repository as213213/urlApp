<?php

namespace App\Http\Controllers\Api;

use App\Link;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
       
       $data = Link::findOrFail($id);
       $dt= $data->created_at;
       $now = Carbon::now();
       $nw_dt = $now->toDateTimeString();

       $prvious_hr = Link::where('id',$id)
                            ->where("created_at","<", $nw_dt)
                            ->first();
        $pr_hr = $prvious_hr->created_at;


       $api_response = [
            'Short Link' => $data->code,
            'Link' => $data->link,
            'Total Visits' => $data->visitors,
            'Creation Time' => $dt->toDateTimeString(),
            'Previous Hour Visits' => $pr_hr->toDateTimeString()
        ];
    
        return response()->json($api_response);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
