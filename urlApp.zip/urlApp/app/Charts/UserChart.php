<?php

namespace App\Charts;

use ConsoleTVs\Charts\Classes\Chartjs\Chart;

class UserChart extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     parent::__construct();
    // }

    public function __construct()
    {
        parent::__construct();
        
        $this->labels(['Sexual Harrasment', 'FERPA', 'Three'])
            ->options([
               'legend' => [
                   'display' => true
                   
               ] 
            ]);
        $this->displayAxes(true);
        $this->barWidth(true);
    }
}
