@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"><a href="{{url('create')}}"> Create URL</a></div>

                <div class="panel-body">
                         <div class="card-body">

            @if (Session::has('success'))

                <div class="alert alert-success">

                    <p>{{ Session::get('success') }}</p>

                </div>

            @endif

            <table class="table table-bordered table-sm">

                <thead>

                    <tr>

                        <th>Sl.No.</th>

                        <th>Short Link</th>

                        <th>Link</th>
                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                    @foreach($shortLinks as $row)

                        <tr>

                            <td>{{ $row->id }}</td>

                            <td><a href="{{url('singleUser/'.$row->id)}}">{{ $row->code}}</a></td>

                            <td>{{ $row->link }}</td>
                            <td><a href="{{url('api/show/'.$row->id)}}"> View </a></td>

                        </tr>

                    @endforeach

                </tbody>

            </table>

      </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
