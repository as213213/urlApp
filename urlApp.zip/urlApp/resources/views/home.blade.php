@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading"></div>

                <div class="panel-body">
                     <form action="{{url('user/url-generate') }}" method="POST">
                             <input name="_token" type="hidden"
                                        value="{{ csrf_token() }}"/>
                            <div class="form-group row">
                                <div class="col-sm-6">
                                    <input type="hidden" value="{{ Auth::user()->id }}" name="user_id"> 
                                    <label class="col-form-label required-label">
                                        Enter Url 
                                    </label>
                                    <input type="text" class="form-control"
                                         name="url" id="name"
                                                placeholder="Enter url"
                                                value="{{old('url')}}">
                                                @if ($errors->has('url'))
                                                <label class="error">
                                                     {{ $errors->first('url') }}
                                                </label>
                                                @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-12">
                                    <button type="submit" class="btn btn-primary m-b-0">Submit</button>
                                </div>
                            </div>
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
