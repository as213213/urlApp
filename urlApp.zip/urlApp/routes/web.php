<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', 'HomeController@index');
Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
Route::get('/urlList', 'HomeController@urlList');
Route::get('/create', 'HomeController@create');
Route::post('user/url-generate', 'HomeController@store');
Route::get('shortenLink/{id}', 'HomeController@shortenLink');
Route::get('singleUser/{id}', 'HomeController@shortenLinkUser');
// Route::get('show/{id}', 'HomeController@show');
